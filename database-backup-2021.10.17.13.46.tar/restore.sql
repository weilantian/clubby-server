--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE weilantian;
--
-- Name: weilantian; Type: DATABASE; Schema: -; Owner: weilantian
--

CREATE DATABASE weilantian WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE weilantian OWNER TO weilantian;

\connect weilantian

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: QuestionType; Type: TYPE; Schema: public; Owner: weilantian
--

CREATE TYPE public."QuestionType" AS ENUM (
    'CHOOSE',
    'SHORT_TEXT',
    'LONG_TEXT'
);


ALTER TYPE public."QuestionType" OWNER TO weilantian;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: weilantian
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'MEMBER'
);


ALTER TYPE public."Role" OWNER TO weilantian;

--
-- Name: ScheduleType; Type: TYPE; Schema: public; Owner: weilantian
--

CREATE TYPE public."ScheduleType" AS ENUM (
    'COURSE',
    'ACTIVITY',
    'TRIP',
    'OTHER'
);


ALTER TYPE public."ScheduleType" OWNER TO weilantian;

--
-- Name: Sex; Type: TYPE; Schema: public; Owner: weilantian
--

CREATE TYPE public."Sex" AS ENUM (
    'MALE',
    'FEMALE',
    'OTHER',
    'UNSET'
);


ALTER TYPE public."Sex" OWNER TO weilantian;

--
-- Name: Status; Type: TYPE; Schema: public; Owner: weilantian
--

CREATE TYPE public."Status" AS ENUM (
    'APPROVED',
    'WAIT',
    'REJECTED'
);


ALTER TYPE public."Status" OWNER TO weilantian;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AttendanceRecord; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."AttendanceRecord" (
    id text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "scheduleId" text,
    "courseId" text
);


ALTER TABLE public."AttendanceRecord" OWNER TO weilantian;

--
-- Name: ClubInfo; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."ClubInfo" (
    id text DEFAULT 'default'::text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    type text NOT NULL,
    "designedMemberCount" integer NOT NULL
);


ALTER TABLE public."ClubInfo" OWNER TO weilantian;

--
-- Name: Course; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."Course" (
    id text NOT NULL,
    name text NOT NULL,
    "fileLinks" text DEFAULT ''::text NOT NULL,
    content text NOT NULL,
    published boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Course" OWNER TO weilantian;

--
-- Name: Inquiry; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."Inquiry" (
    id text NOT NULL,
    "publisherId" text NOT NULL,
    "answerUserId" text,
    content text DEFAULT ''::text NOT NULL,
    answer text DEFAULT ''::text NOT NULL,
    public boolean NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    "publishedOn" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Inquiry" OWNER TO weilantian;

--
-- Name: JoinRequest; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."JoinRequest" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "wechatQQ" text DEFAULT ''::text NOT NULL,
    "phoneNum" text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    status public."Status" DEFAULT 'WAIT'::public."Status" NOT NULL
);


ALTER TABLE public."JoinRequest" OWNER TO weilantian;

--
-- Name: JoinRequestAnswer; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."JoinRequestAnswer" (
    id text NOT NULL,
    "questionId" text,
    answer text NOT NULL
);


ALTER TABLE public."JoinRequestAnswer" OWNER TO weilantian;

--
-- Name: QuestionnaireQuestion; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."QuestionnaireQuestion" (
    id text NOT NULL,
    type public."QuestionType" NOT NULL,
    choose_options text[],
    question text NOT NULL
);


ALTER TABLE public."QuestionnaireQuestion" OWNER TO weilantian;

--
-- Name: Schedule; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."Schedule" (
    id text NOT NULL,
    name text NOT NULL,
    "startTime" text DEFAULT ''::text NOT NULL,
    type public."ScheduleType" DEFAULT 'COURSE'::public."ScheduleType" NOT NULL,
    custom_type text,
    description text DEFAULT ''::text NOT NULL,
    "fileLinks" text DEFAULT ''::text NOT NULL,
    "courseId" text,
    published boolean DEFAULT false NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    "endTime" text DEFAULT ''::text NOT NULL
);


ALTER TABLE public."Schedule" OWNER TO weilantian;

--
-- Name: Task; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    content text NOT NULL,
    due text NOT NULL,
    finished boolean NOT NULL,
    personal boolean DEFAULT true NOT NULL,
    "publisherId" text NOT NULL
);


ALTER TABLE public."Task" OWNER TO weilantian;

--
-- Name: User; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password text NOT NULL,
    sex public."Sex" DEFAULT 'UNSET'::public."Sex" NOT NULL,
    role public."Role" NOT NULL,
    "roleName" text DEFAULT ''::text NOT NULL,
    activated boolean DEFAULT false NOT NULL
);


ALTER TABLE public."User" OWNER TO weilantian;

--
-- Name: _AttendanceRecordToUser; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."_AttendanceRecordToUser" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_AttendanceRecordToUser" OWNER TO weilantian;

--
-- Name: _ScheduleToUser; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."_ScheduleToUser" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_ScheduleToUser" OWNER TO weilantian;

--
-- Name: _doneBy; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public."_doneBy" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_doneBy" OWNER TO weilantian;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: weilantian
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO weilantian;

--
-- Data for Name: AttendanceRecord; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."AttendanceRecord" (id, date, "scheduleId", "courseId") FROM stdin;
\.
COPY public."AttendanceRecord" (id, date, "scheduleId", "courseId") FROM '$$PATH$$/3403.dat';

--
-- Data for Name: ClubInfo; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."ClubInfo" (id, name, description, type, "designedMemberCount") FROM stdin;
\.
COPY public."ClubInfo" (id, name, description, type, "designedMemberCount") FROM '$$PATH$$/3405.dat';

--
-- Data for Name: Course; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."Course" (id, name, "fileLinks", content, published) FROM stdin;
\.
COPY public."Course" (id, name, "fileLinks", content, published) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: Inquiry; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."Inquiry" (id, "publisherId", "answerUserId", content, answer, public, title, "publishedOn") FROM stdin;
\.
COPY public."Inquiry" (id, "publisherId", "answerUserId", content, answer, public, title, "publishedOn") FROM '$$PATH$$/3401.dat';

--
-- Data for Name: JoinRequest; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."JoinRequest" (id, "userId", "wechatQQ", "phoneNum", email, status) FROM stdin;
\.
COPY public."JoinRequest" (id, "userId", "wechatQQ", "phoneNum", email, status) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: JoinRequestAnswer; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."JoinRequestAnswer" (id, "questionId", answer) FROM stdin;
\.
COPY public."JoinRequestAnswer" (id, "questionId", answer) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: QuestionnaireQuestion; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."QuestionnaireQuestion" (id, type, choose_options, question) FROM stdin;
\.
COPY public."QuestionnaireQuestion" (id, type, choose_options, question) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: Schedule; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."Schedule" (id, name, "startTime", type, custom_type, description, "fileLinks", "courseId", published, date, "endTime") FROM stdin;
\.
COPY public."Schedule" (id, name, "startTime", type, custom_type, description, "fileLinks", "courseId", published, date, "endTime") FROM '$$PATH$$/3395.dat';

--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."Task" (id, content, due, finished, personal, "publisherId") FROM stdin;
\.
COPY public."Task" (id, content, due, finished, personal, "publisherId") FROM '$$PATH$$/3400.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."User" (id, email, name, password, sex, role, "roleName", activated) FROM stdin;
\.
COPY public."User" (id, email, name, password, sex, role, "roleName", activated) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: _AttendanceRecordToUser; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."_AttendanceRecordToUser" ("A", "B") FROM stdin;
\.
COPY public."_AttendanceRecordToUser" ("A", "B") FROM '$$PATH$$/3404.dat';

--
-- Data for Name: _ScheduleToUser; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."_ScheduleToUser" ("A", "B") FROM stdin;
\.
COPY public."_ScheduleToUser" ("A", "B") FROM '$$PATH$$/3402.dat';

--
-- Data for Name: _doneBy; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public."_doneBy" ("A", "B") FROM stdin;
\.
COPY public."_doneBy" ("A", "B") FROM '$$PATH$$/3406.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: weilantian
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3393.dat';

--
-- Name: AttendanceRecord AttendanceRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."AttendanceRecord"
    ADD CONSTRAINT "AttendanceRecord_pkey" PRIMARY KEY (id);


--
-- Name: ClubInfo ClubInfo_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."ClubInfo"
    ADD CONSTRAINT "ClubInfo_pkey" PRIMARY KEY (id);


--
-- Name: Course Course_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_pkey" PRIMARY KEY (id);


--
-- Name: Inquiry Inquiry_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Inquiry"
    ADD CONSTRAINT "Inquiry_pkey" PRIMARY KEY (id);


--
-- Name: JoinRequestAnswer JoinRequestAnswer_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."JoinRequestAnswer"
    ADD CONSTRAINT "JoinRequestAnswer_pkey" PRIMARY KEY (id);


--
-- Name: JoinRequest JoinRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."JoinRequest"
    ADD CONSTRAINT "JoinRequest_pkey" PRIMARY KEY (id);


--
-- Name: QuestionnaireQuestion QuestionnaireQuestion_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."QuestionnaireQuestion"
    ADD CONSTRAINT "QuestionnaireQuestion_pkey" PRIMARY KEY (id);


--
-- Name: Schedule Schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Schedule"
    ADD CONSTRAINT "Schedule_pkey" PRIMARY KEY (id);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Schedule_courseId_unique; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE UNIQUE INDEX "Schedule_courseId_unique" ON public."Schedule" USING btree ("courseId");


--
-- Name: User.email_unique; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE UNIQUE INDEX "User.email_unique" ON public."User" USING btree (email);


--
-- Name: _AttendanceRecordToUser_AB_unique; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE UNIQUE INDEX "_AttendanceRecordToUser_AB_unique" ON public."_AttendanceRecordToUser" USING btree ("A", "B");


--
-- Name: _AttendanceRecordToUser_B_index; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE INDEX "_AttendanceRecordToUser_B_index" ON public."_AttendanceRecordToUser" USING btree ("B");


--
-- Name: _ScheduleToUser_AB_unique; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE UNIQUE INDEX "_ScheduleToUser_AB_unique" ON public."_ScheduleToUser" USING btree ("A", "B");


--
-- Name: _ScheduleToUser_B_index; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE INDEX "_ScheduleToUser_B_index" ON public."_ScheduleToUser" USING btree ("B");


--
-- Name: _doneBy_AB_unique; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE UNIQUE INDEX "_doneBy_AB_unique" ON public."_doneBy" USING btree ("A", "B");


--
-- Name: _doneBy_B_index; Type: INDEX; Schema: public; Owner: weilantian
--

CREATE INDEX "_doneBy_B_index" ON public."_doneBy" USING btree ("B");


--
-- Name: AttendanceRecord AttendanceRecord_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."AttendanceRecord"
    ADD CONSTRAINT "AttendanceRecord_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AttendanceRecord AttendanceRecord_scheduleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."AttendanceRecord"
    ADD CONSTRAINT "AttendanceRecord_scheduleId_fkey" FOREIGN KEY ("scheduleId") REFERENCES public."Schedule"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Inquiry Inquiry_answerUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Inquiry"
    ADD CONSTRAINT "Inquiry_answerUserId_fkey" FOREIGN KEY ("answerUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Inquiry Inquiry_publisherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Inquiry"
    ADD CONSTRAINT "Inquiry_publisherId_fkey" FOREIGN KEY ("publisherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: JoinRequestAnswer JoinRequestAnswer_questionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."JoinRequestAnswer"
    ADD CONSTRAINT "JoinRequestAnswer_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES public."QuestionnaireQuestion"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: JoinRequest JoinRequest_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."JoinRequest"
    ADD CONSTRAINT "JoinRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Schedule Schedule_courseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Schedule"
    ADD CONSTRAINT "Schedule_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Task Task_publisherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_publisherId_fkey" FOREIGN KEY ("publisherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _AttendanceRecordToUser _AttendanceRecordToUser_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."_AttendanceRecordToUser"
    ADD CONSTRAINT "_AttendanceRecordToUser_A_fkey" FOREIGN KEY ("A") REFERENCES public."AttendanceRecord"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _AttendanceRecordToUser _AttendanceRecordToUser_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."_AttendanceRecordToUser"
    ADD CONSTRAINT "_AttendanceRecordToUser_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ScheduleToUser _ScheduleToUser_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."_ScheduleToUser"
    ADD CONSTRAINT "_ScheduleToUser_A_fkey" FOREIGN KEY ("A") REFERENCES public."Schedule"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _ScheduleToUser _ScheduleToUser_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."_ScheduleToUser"
    ADD CONSTRAINT "_ScheduleToUser_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _doneBy _doneBy_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."_doneBy"
    ADD CONSTRAINT "_doneBy_A_fkey" FOREIGN KEY ("A") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _doneBy _doneBy_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weilantian
--

ALTER TABLE ONLY public."_doneBy"
    ADD CONSTRAINT "_doneBy_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

